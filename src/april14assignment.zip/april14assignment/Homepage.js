export default function HomePage(){
    return(
        <div>
            <p>
            We offer 20 + Programming languages Training in Bangalore - Koramangala, BTM Layout and Marathahalli. 
            We also offer fast track Coding Bootcamps in Bangalore on Angular 2, JavaScript, ReactJS, AI and Spring and Hibernate.
            Our Trainers are 10+ years of experienced industry experts, and presently consulting many MNCs and Corporate organisations. 
            All our classroom based courses also include students participating via Online facilities from various parts of India and across the Globe.  
            </p>
        </div>
    )
}